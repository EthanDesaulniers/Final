﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameController : MonoBehaviour {


	public Text questionText;
	public Text scoreDisplayText;
	public Text timeRemainingDisplayText;
	public SimpleObjectPool answerButtonObjectPool;
	public Transform answerButtonParent;
	public GameObject questionDisplay;
	public GameObject roundEndDisplay;

	private DataController dataController;
	private RoundData currentRoundData;
	private QuestionData[] questionPool;

	public bool isRoundActive;
	public float timeRemaining;
	public int questionIndex;
	public int playerScore;
	public List<GameObject> answerButtonGameObjects = new List<GameObject>();

	public GameObject quizTime;
	GameObject quizCopy;

	// Use this for initialization
	void Start () 
	{
		dataController = FindObjectOfType<DataController> ();
		currentRoundData = dataController.GetCurrentRoundData ();
		questionPool = currentRoundData.questions;
		timeRemaining = currentRoundData.timeLimitInSeconds;
		UpdateTimeRemainingDisplay ();

		playerScore = 0;
		questionIndex = 0;

		ShowQuestion ();
		isRoundActive = true;
	}

	private void ShowQuestion()
	{	

		RemoveAnswerButtons ();
		QuestionData questionData = questionPool [questionIndex];
		questionText.text = questionData.questionText;

		for (int i = 0; i < questionData.answers.Length; i++) 
		{
			GameObject answerButtonGameObject = answerButtonObjectPool.GetObject ();
			answerButtonGameObjects.Add (answerButtonGameObject);
			answerButtonGameObject.transform.SetParent (answerButtonParent);

			AnswerButton answerButton = answerButtonGameObject.GetComponent<AnswerButton> ();
			answerButton.Setup(questionData.answers[i]);
		}
	}

	private void RemoveAnswerButtons()
	{
		while (answerButtonGameObjects.Count > 0) 
		{
			answerButtonObjectPool.ReturnObject (answerButtonGameObjects [0]);
			answerButtonGameObjects.RemoveAt (0);
		}
	}

	public void AnswerButtonClicked(bool isCorrent)
	{
		if (isCorrent) 
		{
			playerScore += currentRoundData.Points;
			scoreDisplayText.text = "Score: " + playerScore.ToString ();
		}

		if (questionPool.Length > questionIndex + 1) 
		{
			questionIndex++;
			ShowQuestion ();
		} 
		else 
		{
			EndRound ();
		}
	}

	public void EndRound()
	{
		isRoundActive = false;

		questionDisplay.SetActive (false);
		roundEndDisplay.SetActive (true);
	}

	public void ReturnToMenu()
	{
		SceneManager.LoadScene ("MenuScreen");
	}

	private void UpdateTimeRemainingDisplay()
	{
		timeRemainingDisplayText.text = "Time: " + Mathf.Round (timeRemaining).ToString ();
	}

	// Update is called once per frame
	void Update () 
	{
		//Debug.Log ((int)Time.timeSinceLevelLoad%10);

		if (isRoundActive) 
		{
			timeRemaining -= Time.deltaTime%10;
			UpdateTimeRemainingDisplay ();

			if (timeRemaining <= 0f) 
			{
				EndRound ();
			}
		}

		//if((int)Time.timeSinceLevelLoad %10 == 0 && isRoundActive == false)
		//{
		//	quizCopy = Instantiate(quizTime, new Vector3(Screen.width/2,Screen.height/3, -0.01f), Quaternion.identity);
		//	Destroy (quizCopy, 1);
        //
		//	dataController = FindObjectOfType<DataController> ();
		//	currentRoundData = dataController.GetCurrentRoundData ();
		//	questionPool = currentRoundData.questions;
		//	timeRemaining = currentRoundData.timeLimitInSeconds;
		//	UpdateTimeRemainingDisplay ();
        //
		//	ShowQuestion ();
		//	isRoundActive = true;
		//	timeRemaining = 10;
        //
		//	questionDisplay.SetActive (true);
		//	roundEndDisplay.SetActive (false);
		//}
	}
}
